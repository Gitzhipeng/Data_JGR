clc
clear
%%
lambda=0.5;
mu=0.35;
beta=1;
v=0.040;%0.2854;
D=0.07;%0.8563;
%%
xL=0;
xR=20;
xN=200;
dx=(xR-xL)/xN;
tL=0;
tM=400;
tN=40000;
dt=(tM-tL)/tN;
x=xL:dx:xR;
t=tL:dt:tM;
%%
k1=-v*dt/dx;
k2=D*dt/(dx)^2;
C=zeros(xN+1,tN+1);
Cim=zeros(xN+1,tN+1);
M=zeros(xN+1,xN+1);
rhs=zeros(xN+1,1);
C(1,1)=1;%Instantaneous source
%%
%Main
for i=1:xN
    for j=1:xN+1
        if i==j
            M(i,j)=1+k1+2*k2;
        elseif i==j-1
            M(i,j)=-k1-k2;
        elseif i==j+1
            M(i,j)=-k2;
        else
            M(i,j)=0;
        end
    end
end
M(1,:)=0; M(xN+1,:)=0;
M(1,1)=1;
M(xN+1,xN+1)=1; M(xN+1,xN)=-1;

for j=2:tN+1
    for i=1:xN+1
        Cim(i,j)=Cim(i,j-1)+dt*lambda*C(i,j-1)-dt*mu*Cim(i,j-1);
    end
    for i=1:xN+1
        rhs(i)=C(i,j-1)-beta*(Cim(i,j)-Cim(i,j-1));
    end
    if j>3
    rhs(1)=1;
    rhs(xN+1)=0;
    end
    C(:,j)=M\rhs;  
end
T=355;
t_plot=(T/(tM-tL))*tN+1;
%c_plot=C(:,t_plot);
c_plot=C(20:end,t_plot)/max(C(20:end,t_plot));

%data=[x' c_plot];
hold on
plot(x(20:end),c_plot)
data=[x(20:end)' c_plot]

