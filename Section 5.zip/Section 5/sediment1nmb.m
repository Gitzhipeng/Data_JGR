function labsun
%Sediment transport data for 1mm
% p=1;%Experimental index
clc % Clear
% tic; % Time account
% alpha=0.980;%derivative order
% u0=0.1;%Ħ������
% m1=1/7;
% sa1=10^4*[0.098849765373214 0.075589482887494 0.006830245360156 0.227362950858492 0.384755053039411 0.369743043987945 0.519240065265061 0.580113605244918 0.065838298672672 0.072201569229684 1.155276645906815 0.987720366603805 0.833249837453838 0.089831353809489 0.022887293176403 0.014783653739388 0.100784375105701];
% concentration at 0.05H
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Experimental data
[X1mma1]=textread('1mma-spatial.txt','%f');
[X1mma2]=textread('1mma-number.txt','%f');
[X1mmb1]=textread('1mmb-spatial.txt','%f');
[X1mmb2]=textread('1mmb-number.txt','%f');
X1mma1=20-X1mma1;
X1mma2=X1mma2/max(X1mma2);
X1mmb1=20-X1mmb1;
X1mmb2=X1mmb2/max(X1mmb2);
% l=[0.2 0.4 0.8];
X2mma1=X1mma1(1:length(X1mma1)-20);
X2mma2=X1mma2(1:length(X1mma2)-20);
X2mmb1=X1mmb1(1:length(X1mmb1)-15);
X2mmb2=X1mmb2(1:length(X1mmb2)-15);
hold on
plot(X2mma1,X2mma2,'g*') % Plot the Rouse result
 hold on
plot(X2mmb1,X2mmb2,'r*') % Plot the Rouse result
% legend('Fractional model','Rouse equation','Experimental data')
% xlabel('Depth H')
% ylabel('Concentration (%)')
