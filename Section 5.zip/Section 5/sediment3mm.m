function labmmm
%Sediment transport data for 3mm
% p=1;%Experimental index
clc % Clear
% tic; % Time account
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Experimental data
[X1mma1]=textread('3mma-spatial.txt','%f');
[X1mma2]=textread('3mma-number.txt','%f');
[X1mmb1]=textread('3mmb-spatial.txt','%f');
[X1mmb2]=textread('3mmb-number.txt','%f');
X1mma1=20-X1mma1;
X1mma2=X1mma2/max(X1mma2);
X1mmb1=20-X1mmb1;
X1mmb2=X1mmb2/max(X1mmb2);
X2mma1=X1mma1(1:length(X1mma1)-5);
X2mma2=X1mma2(1:length(X1mma2)-5);
X2mmb1=X1mmb1(1:length(X1mmb1)-3);
X2mmb2=X1mmb2(1:length(X1mmb2)-3);
% l=[0.2 0.4 0.8];
hold on
plot(X2mma1,X2mma2,'k*') % Plot the Rouse result
% hold on
plot(X2mmb1,X2mmb2,'g*') % Plot the Rouse result
% legend('Fractional model','Rouse equation','Experimental data')
% xlabel('Depth H')
% ylabel('Concentration (%)')
